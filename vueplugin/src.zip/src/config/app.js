/**
 * @author caijianjia
 * @date 2021-10-13 16:54
 */
export const config = {
    device: 'pc' // pc | h5
}
