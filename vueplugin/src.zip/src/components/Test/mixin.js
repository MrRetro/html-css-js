/**
 * @author caijianjia
 * @date 2021-10-13 15:35
 */
module.exports = {
    methods: {
        click(value){
            console.log('myClick', value)
        }
    }
}
