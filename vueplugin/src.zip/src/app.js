/**
 * @author caijianjia
 * @date 2021-10-13 14:57
 */
export default {
    methods: {
        /*#__PURE__*/ handleClick(){
            let a = '1'
            console.log('yes==>', a)
        }
    }
}

export function test1(){
    console.log('test1')
}

export function test2(){
    console.log('test2')
}
